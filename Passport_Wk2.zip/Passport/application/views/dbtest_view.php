<h1> Sample DB Test</h1><br />
<b>Active Record Query</b> <pre><?php print_r($query_ar->result_array()); ?></pre><br />